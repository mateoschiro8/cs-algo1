#ifndef CASES_INCLUDED_H
#define CASES_INCLUDED_H

using namespace std;

bool test01_existePico();
bool test02_mcd();
bool test03_indiceMinSubsec();
bool test04_ordenar1();
bool test05_ordenar2();
bool test06_division();

#endif //CASES_INCLUDED_H
